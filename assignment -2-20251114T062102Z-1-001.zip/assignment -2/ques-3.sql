create database apollo;
use apollo;
CREATE TABLE Hospital (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_name VARCHAR(255) NOT NULL,
    disease VARCHAR(30),
    bill_amount INT CHECK (bill_amount <= 200000)
);
INSERT INTO Hospital (patient_name, disease, bill_amount) VALUES
('rohit', 'Fever', 35000),
('ankit', 'Flu', 75000),
('aditya', 'COVID-19', DEFAULT);
SELECT * FROM Hospital WHERE bill_amount > 50000;
SELECT * FROM Hospital WHERE disease = 'Flu' OR bill_amount < 10000;
SELECT DISTINCT disease FROM Hospital;
SELECT * FROM Hospital ORDER BY bill_amount DESC LIMIT 2;
SELECT * FROM Hospital WHERE bill_amount BETWEEN 20000 AND 80000 ORDER BY bill_amount ASC;
SELECT disease, COUNT(*) AS patient_count FROM Hospital GROUP BY disease;
SELECT * FROM Hospital WHERE bill_amount = (SELECT MIN(bill_amount) FROM Hospital);

