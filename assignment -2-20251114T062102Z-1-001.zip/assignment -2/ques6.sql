create database school;
use school;
DROP TABLE IF EXISTS Teacher;


CREATE TABLE Teacher (
    teacher_id INT PRIMARY KEY AUTO_INCREMENT,
    teacher_name VARCHAR(255) NOT NULL,
    subject VARCHAR(30),
    salary INT CHECK (salary <= 80000)
);

INSERT INTO Teacher (teacher_name, subject, salary) VALUES
('mukesh', 'Maths', 65000),
('sakhan', 'Maths', NULL),
('asha', 'Physics', 45000);

SELECT *FROM Teacher WHERE salary > 50000;
SELECT *FROM Teacher WHERE subject = 'Maths' OR salary < 30000;
SELECT DISTINCT subject FROM Teacher;
SELECT * FROM Teacher ORDER BY salary DESC LIMIT 1;
SELECT * FROM Teacher WHERE salary BETWEEN 20000 AND 70000 ORDER BY salary ASC;
SELECT subject, COUNT(teacher_id) FROM Teacher GROUP BY subject;
SELECT *FROM Teacher ORDER BY salary ASC LIMIT 1;
 