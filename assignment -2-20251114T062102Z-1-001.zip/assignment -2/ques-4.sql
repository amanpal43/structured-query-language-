create database  tommy;
use tommy;
CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(255) NOT NULL,
    product VARCHAR(40),
    amount INT CHECK (amount <= 50000) DEFAULT 0
);

INSERT INTO Orders (customer_name, product, amount) VALUES
('amanpal', 'Laptop', 25000),
('mayank', 'Smartphone', 15000),
('himanshu', 'Keyboard', DEFAULT);
SELECT * FROM Orders WHERE amount > 10000;
SELECT * FROM Orders WHERE product = 'Laptop' OR amount < 5000;
SELECT DISTINCT product FROM Orders;
SELECT * FROM Orders ORDER BY amount DESC LIMIT 2;
SELECT * FROM Orders WHERE amount BETWEEN 8000 AND 30000 ORDER BY amount;
SELECT product, COUNT(*) AS number_of_orders FROM Orders GROUP BY product;
SELECT MAX(amount) AS max_amount FROM Orders;
