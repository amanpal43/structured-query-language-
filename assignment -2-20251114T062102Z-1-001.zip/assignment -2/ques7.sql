create database movie;
use movie;
CREATE TABLE Cinema (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    movie_name VARCHAR(255) UNIQUE NOT NULL,
    language VARCHAR(20),
    rating INT CHECK (rating <= 10)
);
INSERT INTO Cinema (movie_name, language, rating) VALUES
('intesteller', 'English', 9),
('demonslayer', 'Korean', 10),
('kabirsingh', 'Hindi', NULL);

SELECT *FROM Cinema WHERE rating > 7;
SELECT *FROM Cinema WHERE language = 'Hindi' OR rating < 5;
SELECT DISTINCT language FROM Cinema;
SELECT movie_name, rating FROM Cinema ORDER BY rating DESC LIMIT 2;
SELECT movie_name, rating FROM Cinema WHERE rating BETWEEN 5 AND 9 ORDER BY rating ASC;
SELECT language, COUNT(*) AS number_of_movies FROM Cinema GROUP BY language;
SELECT movie_name, rating FROM Cinema WHERE rating = (SELECT MAX(rating) FROM Cinema);
