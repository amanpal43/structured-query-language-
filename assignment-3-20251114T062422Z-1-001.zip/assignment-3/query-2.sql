create database park;
use park;
create table Students(student_id INT PRIMARY KEY AUTO_INCREMENT,
Name VARCHAR(50), 
Course VARCHAR(30), 
Marks INT, 
Attendance INT, 
Grade CHAR(1) );

INSERT INTO students(Name, course, marks, attendance, grade) VALUES 
('Aarav', 'Maths', 85, 90, 'A'), 
('Riya', 'Science', 72, 88, 'B'), 
('Kabir', 'English', 60, 70, 'C'), 
('Neha', 'Maths', 95, 92, 'A'), 
('Rahul', 'Science', 50, 65, 'D');

SELECT * FROM students;
UPDATE students SET marks = LEAST(marks + 5, 100) WHERE attendance > 85;
SELECT student_id, name, course, marks, CASE
    WHEN marks >= 90 THEN 'Excellent'
    WHEN marks >= 75 THEN 'Good'
    WHEN marks >= 50 THEN 'Average'
    ELSE 'Poor'
  END AS performance FROM students;
SELECT course, AVG(marks) AS avg_marks FROM students GROUP BY course;
SELECT course, AVG(marks) AS avg_marks FROM students GROUP BY course HAVING AVG(marks) > 75;
SELECT course,
		SUM(marks) AS total_marks,
       AVG(attendance) AS avg_attendance
FROM students GROUP BY course;
UPDATE students SET marks = LEAST(CEIL(marks * 1.10), 100) WHERE course = 'Maths';
SELECT MAX(marks) AS max_marks, MIN(marks) AS min_marks FROM students;
SELECT * FROM students ORDER BY attendance DESC;
SELECT course, COUNT(*) AS student_count FROM students GROUP BY course HAVING COUNT(*)> 1;